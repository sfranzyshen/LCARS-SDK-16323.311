<div class="description">
<p>One of the trademarks of LCARS is its use of color.  Many fans have created assortments of color patterns, values and groups based off the original work from Mr. Okuda and Mr. Drexler.  Even more, many of the canon interfaces are backlit and not monitor based RGB making color translation a bit of a pickle.</p>

<p>The SDK does not include any pre-packaged colors except a standard grey (#505050) white and transparent.  All colors used within a project are setup by the developer using whatever color names they prefer to represent their chosen color code values.  There is an optional color theme provided in the SDK called the USS Not Affiliated, which currently is the SDK branding colors.</p>  

<p>Border color is include in the color settings because Elbows, for their innerRadius, use a border trick to enable a reverse-border-radius.  </p>

<p>Color sets should be the last thing in a projects CSS file mainly to ensure proper overriding with the typical color flashes, changes and states.  Inherited colors go before the direct color placement.</p>
</div>

<p>Color grouping is currently following a specific pattern:  5 Primary, 4 Secondary, 3 Accent, 2 Highlight, a total of 14 core colors with lowest numbers being the brightest shade of the group and working down.</p>
<p>The naming of the colors follows a pattern, as examples:  primary1, secondary3, accent2, highlight1.</p>
<p>Additional colors use just the color name and then the numerical value like:  red2, green1, violet4.<p>
<p>By utilizing these patterns, color templates can be swapped in and out on the fly without major worry that something will go amiss.</p>

<pre class="code hidden">

.primary1>.bar, .primary1>.block, .primary1>.button, .primary1>.cap{background-color:#3366FF; border-color:#3366FF;}
.secondary1>.bar, .secondary1>.block, .secondary1>.button, .secondary1>.cap{background-color:#00cc99; border-color:#00cc99;}


.grey>.bar, .grey>.block, .grey>.button, .grey>.cap{background-color:#505050; border-color:#505050;}
.white>.bar, .white>.block, .white>.button, .white>.cap{background-color:#ffffff; border-color:#ffffff;}
.transparent>.bar, .transparent>.block, .transparent>.button, .transparent>.cap{background-color:transparent; border-color:transparent;}

.grey:not(.complexButton){background-color:#505050; border-color:#505050;}
.white:not(.complexButton){background-color:#ffffff; border-color:#ffffff;}
.transparent:not(.complexButton){background-color:transparent; border-color:transparent;}
.primary1:not(.complexButton){background-color:#3366FF; border-color:#3366FF;}
.secondary1:not(.complexButton){background-color:#00cc99; border-color:#00cc99;}


//Sample object definition.
{type:'button', label:'text', color:'burnt-orange'}

//translates to DOM Object:
&lt;div class="button" data-type="button" data-label="text" data-color="burnt orange"&gt;&lt;/div&gt;

//Set-Get-Clear
$(element).objecSettings('color') => Get
$(element).objecSettings({color:'red'}); => Set

$(element).objecSettings({color:['red', 'burnt orange', 'blue']}); => Set randomly selected color from array

var colorArray = ['red', 'burnt orange', 'blue'];
$(element).objecSettings({color:colorArray}); => Set randomly selected color from array

$(element).objecSettings({color:null}); => Remove
</pre> 