'webviewInfo' is a global variable that is maintained by modified version of Matthew Hudson's device.js library. This is required else aspects of the SDK will not function properly.

Generally this file is in a minimized form but is released unminified for easy tweaking.

`os              - 'ios/android/blackberry/windows/ffos/meego'`<br> 
`device	        - 'ipod/ipad/iphone'`<br>
`orientation	- 'landscape/portrait'`<br>
`input           - 'desktop/touch'`<br>
`type            - 'mobile/tablet'`<br>
`ie              - true`<br>

`webviewInfo = {os:null, device:null, orientation:null, input:null, type:null, ie:null}`