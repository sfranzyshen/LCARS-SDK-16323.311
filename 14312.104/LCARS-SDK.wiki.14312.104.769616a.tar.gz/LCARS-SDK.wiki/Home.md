The LCARS SDK Code core uses a simple API to create and manipulate elements.  While LCARS design sways depending on the series, the SDK provides a built-in base style that can be overwritten with minimal CSS.

The Code core API tries not to be possessive over naming but there are a few co-opted terms used for built in features.
