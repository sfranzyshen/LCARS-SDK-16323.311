## General Information

Since relative patching will change based on an individuals project, below is an easy copy/paste template.

<pre><code>

&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
    &lt;meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /&gt;
    &lt;meta name="format-detection" content="telephone=no" /&gt;
    &lt;meta name="viewport" content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width, height=device-height, target-densitydpi=device-dpi" /&gt;

    &lt;title&gt;LCARS SDK 4.0&lt;/title&gt;

    &lt;!-- Core JS --&gt;
    &lt;script type="text/javascript" src="lcars-sdk/core/jquery.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/core/jquery.mobile-events.min.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/core/arrive.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/core/lcars-sdk.js"&gt;&lt;/script&gt;

    &lt;!-- Elements and Widgets JS--&gt;    
    &lt;script type="text/javascript" src="lcars-sdk/elements/aside.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/elements/bar.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/elements/block.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/elements/button.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/elements/cap.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/elements/column.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/elements/complex-button.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/elements/content.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/elements/details.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/elements/elbow.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/elements/endcap.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/elements/footer.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/elements/header.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/elements/html-tag.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/elements/img.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/elements/main.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/elements/nav.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/elements/oval.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/elements/row.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/elements/section.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/elements/svg.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/elements/text.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/elements/title.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/elements/wrapper.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/widgets/sdk_solid-level-bar/solid-level-bar.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/widgets/sdk_default-bracket/default-bracket.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/widgets/sdk_default-bar-frame/default-bar-frame.js"&gt;&lt;/script&gt;
    &lt;script type="text/javascript" src="lcars-sdk/widgets/sdk_scroll-button/scroll-button.js"&gt;&lt;/script&gt;

    &lt;!-- Project Specific JS--&gt;        
    &lt;script type="text/javascript" src="module.js"&gt;&lt;/script&gt;	   

    &lt;!-- Core and Widgets CSS--&gt;    
    &lt;link rel="stylesheet" type="text/css" href="lcars-sdk/core/lcars-sdk.css"&gt;
    &lt;link rel="stylesheet" type="text/css" href="lcars-sdk/widgets/sdk_solid-level-bar/solid-level-bar.css"&gt;
    &lt;link rel="stylesheet" type="text/css" href="lcars-sdk/widgets/sdk_default-bracket/default-bracket.css"&gt;
    &lt;link rel="stylesheet" type="text/css" href="lcars-sdk/widgets/sdk_default-bar-frame/default-bar-frame.css"&gt;
    &lt;link rel="stylesheet" type="text/css" href="lcars-sdk/widgets/sdk_scroll-button/scroll-button.css"&gt;

    &lt;!-- Color Theme CSS--&gt;    
    &lt;link rel="stylesheet" type="text/css" href="lcars-sdk/themes/sdk_theme-default.css"&gt; 

    &lt;!-- Project Specific CSS--&gt;    
    &lt;link rel="stylesheet" type="text/css" href="module.css"&gt;
    
&lt;/head&gt;

&lt;body ontouchstart="" onload=""&gt;&lt;/body&gt;
&lt;/html&gt;


</code></pre>