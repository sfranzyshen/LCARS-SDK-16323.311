## Element Object

Each element is created using its own prototyped instance.  Prototype naming follows traditional camelCase matched to the file and element class dash(-) naming scheme.

`LCARS.element.button = function(oDef){};`<br>
`LCARS.element.complexButton = function(oDef){};`<br>
`../elements/complex-button.js`<br>
`<div class="complex-button"></div>`

**Included in the LCARS SDK:**

### Style Elements
* bar
* block
* button
* cap
* complex-button
* elbow
* endcap
* html-tag
* img
* oval
* svg
* text
* title

### Semantic & Layout Elements
* aside
* column
* content
* details
* footer
* header
* main
* nav
* row
* section
* wrapper

### Widgets

Widgets are considered elements even though they are made up of smaller elements.  These are namespaced according to their associated groups.

`LCARS.element.sdk.solidLevelBar = function(oDef){};`<br>
`../sdk_solid-level-bar/solid-level-bar.js`<br>
`<div class="sdk solid-level-bar></div>`

* default-bar-frame
* default-bracket
* scroll-button
* solid-level-bar

## Namespace

Namespacing interactive widgets is required to prevent any accidental conflicts. Folders should be prefixed with their abbreviation with an underscore and that information placed in an elements create object.  Included widgets with the LCARS SDK are stored under 'sdk_'

`sdk_`<br>
`../sdk_solid-level-bar/solid-level-bar.js`<br>
`{type:'solidLevelBar', namespace:'sdk', color:'bg-blue-1', level:54}`
