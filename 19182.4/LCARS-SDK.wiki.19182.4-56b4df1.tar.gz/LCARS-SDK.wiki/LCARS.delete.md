Pass either the ID of an element/widget instance or the object itself under `LCARS.active` to remove the item from memory. Before the object instance is deleted all of the attached delete functions of the element/widget will be triggered.  This allows for custom internal cleanup, reference removals, etc...to happen before the object is removed from memory.

`LCARS.delete('buttonSID0ewokltiq')`<br>
`LCARS.delete(LCARS.active.buttonSID0ewokltiq)`

<pre>
//Title Element attached to a Clock system.
    {
        type:'title',
        color:'text-green-4',
        text:'00:00:00',
        style:{'font-size':'50px', 'letter-spacing':'5px', 'font-family':'LCARS Block'},
        receiver:{
            updateTime:function(time){
                this.set('text', time);
            }
        },
        arrive:function(){
            lcars.app.systems.clock.init();
            lcars.app.systems.clock.broadcast[this.data.id] = this.receiver.updateTime;
        },
        delete:{
            detachClock:function(){
                delete lcars.app.systems.clock.broadcast[this.data.id];
            }
        }
    }


</pre>