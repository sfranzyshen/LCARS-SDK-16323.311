The LCARS SDK utilizes the font Antonio Bold by Vernon Adams via Font Squirrel.

https://www.fontsquirrel.com/fonts/antonio?q%5Bterm%5D=antonio+&q%5Bsearch_check%5D=Y

Included is a custom block font based on Antonio Bold.  It is only utilized for when when a sequence of characters is required to be monospaced for visual column alignment of the elements.  This is generally only needed for the larger characters seen between or on the ends of buttons.