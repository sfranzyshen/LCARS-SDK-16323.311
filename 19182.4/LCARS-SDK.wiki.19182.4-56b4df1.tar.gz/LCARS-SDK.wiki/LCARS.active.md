## Active Elements/Widgets

All generated element/widget instances are stored with the key being the element/widget ID.

`LCARS.active`

Type Setting is hardcoded and can not be updated with any of the settings.  A unique ID is generated with the hardcoded type name included.  Store functions within the receiver, event, and broadcast keys.  

The object.dom is a jQuery reference so it does not need to be wrapped as $(object.dom);

<pre>
LCARS.active.buttonSID0ewokltiq

{
   "data":{
      "type":"button",
      "id":"buttonSID0ewokltiq",
      "version":"round-left",
      "color":"bg-blue-2",
      "flexc":"h"
   },
   "receiver":{},
   "event":{},
   "broadcast":{},
   "delete":{},
   "dom":{
      "0":div#buttonSID0ewokltiq.button.round-left.bg-blue-2.flex-c-h,
      "length":1
   }
}

</pre>