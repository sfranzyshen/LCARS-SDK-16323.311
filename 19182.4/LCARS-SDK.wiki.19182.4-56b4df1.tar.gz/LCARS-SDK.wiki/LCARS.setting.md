## Global Settings

These are general settings that handle adding/removing specific classes or other attributes for an element.  They are not attached to an elements prototype and such require the object to be passed.  Any global setting can be overridden on a per element/widget basis within that elements/widgets prototype.

All elements should come with the premade setter and getter:

`LCARS.active.elementID.set('settingName', value);`<Br>
`LCARS.active.elementID.get('settingName');`

### altLabel

`Sets:  DOM Attribute | data-altLabel="value"`<br>
`Pass:  String`

### attr

`Sets:  DOM Attributes`<br>
`Pass-Set:  object | {'attrName':'attrValue', 'attrName2':'attrValue2'}`<br>
`Pass-Remove:  object | {'attrName':null}`

### class

`Sets:  DOM Class`<br>
`Pass-Set:  object | {'className':true, 'className2':true}`<br>
`Pass-Remove:  object | {'className2':false}`

### children

This setting does not set anything but instead creates the child elements of this element.  The setting is recursive so it will continue to loop until there are no more children to create.  Additionally, if a DOM string is passed it will simply be appended to the parent element.

`Pass:  Array of Objects | [{type:'button'}, {type:'button'}, {type:'row', children:[{...}]}]`<br>
`Pass:  String | <div><h2>Some Text</h2></div>`

### color

For the `text || title` elements there is a built in replace to swap the standard 'bg-' prefix for 'text-'.

`Sets:  DOM Class`<br>
`Pass-Set:  String | 'bg-blue-3' || 'text-red-2'`<br>
`Pass-Remove:  null`

### colors

This setting is generally used to quickly assign color values to child elements within a parent.  Each direct child of the parent, in order, matching indexes to the passed array of color strings.

**Loops through and calls the `color` setting** 

`Sets:  DOM Classes`<br>
`Pass-Set:  Array | ['bg-blue-3', 'bg-green-1', 'bg-blue-5']`<br>
`Pass-Remove:  ['bg-blue-3', null, 'bg-blue-5']`

### direction

`Sets:  DOM Class`<br>
`Pass-Set:  String`<br>
`Pass-Remove:  null`

### disabled

`Sets:  CSS Class - .disabled`<br>
`Pass:  Boolean`

### fade

`Sets:  CSS Class - .fade`<br>
`Pass:  Boolean`

### flex

`Sets:  CSS Class | .flex-v || .flex-h`<br>
`Pass-Set:  String | v || h`<br>
`Pass-Remove:  null`

### flexc

`Sets:  CSS Class | .flex-c-v|| .flex-c-h`<br>
`Pass-Set:  String | v || h`<br>
`Pass-Remove:  null`

### hidden

`Sets:  CSS Class | .hidden`<br>
`Pass:  Boolean`

### href

`Sets:  DOM  Attribute`<br>
`Pass-Set:  String`<br>
`Pass-Remove:  null`

### html

Empties the element and appends the passed html string.  HTML created this way is not tracked or maintained within the LCARS framework.  Best used for dynamic content areas continually updated with raw html.

`Sets:  Creates DOM Objects`<br>
`Pass-Set:  String`<br>
`Pass-Remove:  null`

### inputValue

`Sets:  DOM Attribute`<br>
`Pass-Set:  String`<br>
`Pass-Remove:  null`

### label

`Sets:  DOM Attribute | data-altLabel="value"`<br>
`Pass-Set:  String`<br>
`Pass-Remove:  null`

### name

`Sets:  DOM Attribute`<br>
`Pass-Set:  String`<br>
`Pass-Remove:  null`

### group

`Sets:  DOM Attribute | data-group="value"`<br>
`Pass-Set:  String`<br>
`Pass-Remove:  null`

### noEvent

`Sets:  CSS Class | .no-event`<br>
`Pass:  Boolean`

### noTransition

`Sets:  CSS Class | .no-transition`<br>
`Pass:  Boolean`

### password

Turns an Text Input into a Password Input

`Sets:  DOM Attribute`<br>
`Pass:  Boolean`

### readOnly

Makes an input Read Only

`Sets:  DOM Attribute`<br>
`Pass:  Boolean`

### reverse

`Sets:  CSS Class | .reverse`<br>
`Pass:  Boolean`

### size

`Sets:  DOM Class`<br>
`Pass-Set:  String`<br>
`Pass-Remove:  null`

### src

`Sets:  DOM Attribute`<br>
`Pass-Set:  String`<br>
`Pass-Remove:  null`

### state

`Sets:  DOM Class`<br>
`Pass-Set:  String`<br>
`Pass-Remove:  null`

### style

`Sets:  Inline CSS`<br>
`Pass-Set:  object | {'style-name':'value', 'max-height':'190px'}`<br>
`Pass-Remove:  object | {'style-name':false}`

### text

`Sets:  DOM Content`<br>
`Pass-Set:  String`
`Pass-Remove:  null`

### toggle

Allows an element to have a toggle state.  Visual representation is project independent.  Toggle state will only toggle if a mouse/touch event is attached to the element.  For 'eyecandy' switches simply attach an empty function to the click event.

`Sets:  CSS Class | .toggle`<br>
`Pass:  Boolean`<br>

**Events That Accept Toggle Action:**

* click
* mouseup
* tapend 
* tap 
* singletap 
* doubletap 
* taphold 
* swipe
* swipeup
* swiperight
* swipedown
* swipeleft
* swipeend
* tap2
* taphold2

### toggleGroup

`Sets:  DOM Attribute | data-toggleGroup="value"`<br>
`Pass-Set:  String`<Br>
`Pass-Remove:  null`

### version

`Sets:  DOM Class`<br>
`Pass-Set:  String`<Br>
`Pass-Remove:  null`

### arrive & leave

Attach a function to trigger when an element enters the DOM and another function to trigger when an element leaves the dom.

**Functions gets bound to the prototype instance.**

_Do not use Leave as a substitute for Delete. There is no guarentee the prototype will still exist while the Leave function triggers.  Use Leave as an internal function while an element/widget is functioning._

`Pass-Set:  Function`<Br>
`Pass-Remove:  null`

https://github.com/uzairfarooq/arrive

### event

General function group.  

**Functions gets bound to the prototype instance.**

`Pass-Set:  Object | {functionName:function(){}, functionName:function(){}}`<br>

### receiver

Function group to receive data.  

**Functions gets bound to the prototype instance.**

`Pass-Set:  Object | {functionName:function(){}, functionName:function(){}}`<br>

### delete

Functions that are looped through when the `LCARS.delete` is called.  

**Functions get bound to the prototype instance.**

`Pass-Set:  Object | {functionName:function(){}, functionName:function(){}}`<br>

## Mouse, Touch & Screen Events

Mouse/Tap/Screen events are where the majority of jQuery is utilized in the LCARS SDK.  Only use Mouse events when there is no concern for device/input variation.

For touch events:  https://github.com/benmajor/jQuery-Touch-Events

**Functions 'this' are bound to the prototype instance.**

`Pass-Set:  Function `

* click
* mouseenter
* mouseleave
* mousedown
* mouseup
* mousemove
* mouseout
* mouseover
* hover

* tapstart
* tapend 
* tap 
* singletap 
* doubletap 
* taphold 
* swipe
* swipeup
* swiperight
* swipedown
* swipeleft
* swipeend
* tap2
* taphold2

* scrollstart
* scrollend
* orientationchange


