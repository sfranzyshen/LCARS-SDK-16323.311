## New Element Object

<div class="description">
<p><strong>Return:</strong>  New Constructor Prototype Instance Reference of the created object stored under:</p></div>

`LCARS.active['idOfElement']`<br>
`LCARS.active.idOfElement`<br>
`log: {data: {…}, receiver: {…}, event: {…}, broadcast: {…}, delete: {…}, …}`

<pre class="code hidden">
//Basic Usage
var element = LCARS.create({type:'button', color:'bg-blue-1', label:'Button'});

//Append To Body
$('body').append( LCARS.create({type:'button', color:'bg-blue-1', label:'Button'}).dom );

//Create From Array - Returns Array of Active Prototype Instances
var aElements = LCARS.create([
    {type:'button', color:'bg-blue-1', label:'Button'}, 
    {type:'button', color:'bg-blue-1', label:'Button'}
]);
</pre>