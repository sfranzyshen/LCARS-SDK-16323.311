Wiki Guide 19182.4 (LCARS SDK 4.0.0)
 
The LCARS SDK comes in three parts:

1. Illustrator files for mockups and direct sizing porting.
2. Base CSS which is the minimal requirement to utilize the LCARS methodology.
3. JS API which is optional but useful for creating, managing and maintaining the interfaces.

