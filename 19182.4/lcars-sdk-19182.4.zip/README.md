lcars-sdk-19182.4.zip
============
lcars-sdk-19182.4\19182.4
lcars-sdk-19182.4\arrive.js					
lcars-sdk-19182.4\jquery.js
lcars-sdk-19182.4\jquery.mobile-events.js
lcars-sdk-19182.4\lcars-sdk-19182.4.css
lcars-sdk-19182.4\lcars-sdk-19182.4.js
lcars-sdk-19182.4\index.html
lcars-sdk-19182.4\LICENSE.md
lcars-sdk-19182.4\README.md

This is a OFFLINE deployment model for the LCARS-SDK project. Take a look at the index.html to get an idea about how to
set things up. Also, refer to the offical development site and read the wiki. If you need to support older browsers 
(that requires a differnt font other than the woff2 format) download the lcars-sdk-fonts-19182.4.zip archive and 
extract it (also on the LCARS-SDK-ARCHIVE development page) into the same folder where lcars-sdk-19182.4.css file resides.


For more information about our work ... LCARS-SDK-ARCHIVE: **(Our work! not offical)**
https://github.com/sfranzyshen/LCARS-SDK-ARCHIVE/tree/gh-pages


For more information on the LCARS-SDK: **(Offical Active Project!)**

http://www.lcarssdk.org/ <br>
https://www.facebook.com/LCARSSDK <br>
https://github.com/Aricwithana/LCARS-SDK/wiki <br>

To learn how to use the LCARS SDK read through the attached wiki.
