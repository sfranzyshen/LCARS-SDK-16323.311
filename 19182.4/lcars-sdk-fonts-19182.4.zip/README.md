lcars-sdk-fonts-19182.4.zip
====================================
lcars-sdk\19182.4
lcars-sdk\CHANGELOG.md
lcars-sdk\LICENSE.md
lcars-sdk\README.md
lcars-sdk\fonts\Antonio-Bold.ttf
lcars-sdk\fonts\antonio-bold-webfont.eot
lcars-sdk\fonts\antonio-bold-webfont.svg
lcars-sdk\fonts\antonio-bold-webfont.woff
lcars-sdk\fonts\antonio-bold-webfont.woff2
lcars-sdk\fonts\antonio-bold-webfont.woff2.base64
lcars-sdk\fonts\LCARS-Mono.ttf
lcars-sdk\fonts\lcars-mono-webfont.eot
lcars-sdk\fonts\lcars-mono-webfont.svg
lcars-sdk\fonts\lcars-mono-webfont.woff
lcars-sdk\fonts\lcars-mono-webfont.woff2
lcars-sdk\fonts\lcars-mono-webfont.woff2.base64
lcars-sdk\fonts\sdk_fonts-default.css
lcars-sdk\fonts\sdk_fonts-embed.css
lcars-sdk\fonts\sdk_fonts-github.css
lcars-sdk\fonts\SIL Open Font License.txt

This is a OFFLINE deployment model for the LCARS-SDK project. If you need to support older browsers that require 
a differnt font other than the woff2 format then extract this archive into the same folder where the 
lcars-sdk-19182.4.css file resides. That's it!


For more information about our work ... LCARS-SDK-ARCHIVE: **(Our work! not offical)**
https://github.com/sfranzyshen/LCARS-SDK-ARCHIVE/tree/gh-pages


For more information on the LCARS-SDK: **(Offical Active Project!)**

http://www.lcarssdk.org/ <br>
https://www.facebook.com/LCARSSDK <br>
https://github.com/Aricwithana/LCARS-SDK/wiki <br>

To learn how to use the LCARS SDK read through the attached wiki.
